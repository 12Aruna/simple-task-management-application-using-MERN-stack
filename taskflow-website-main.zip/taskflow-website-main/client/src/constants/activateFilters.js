const activateFilters = [
  { buttonTxt: "All", value: "all" },
  { buttonTxt: "Current", value: "current" },
  { buttonTxt: "Overdue", value: "overdue" },
  { buttonTxt: "Upcoming", value: "upcoming" },
  { buttonTxt: "Completed", value: "completed" },
];

export default activateFilters;
