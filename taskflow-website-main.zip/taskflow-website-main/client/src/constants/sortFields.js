const sortFields = [
  { name: "First start first", value: "startDate:1" },
  { name: "Last start first", value: "startDate:-1" },
  { name: "First finish first", value: "finishDate:1" },
  { name: "Last finish first", value: "finishDate:-1" },
  { name: "First update first", value: "updatedAt:1" },
  { name: "Last update first", value: "updatedAt:-1" },
  { name: "First created first", value: "createdAt:1" },
  { name: "Last created first", value: "createdAt:-1" },
];

export default sortFields;
